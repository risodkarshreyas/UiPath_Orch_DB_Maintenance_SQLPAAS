declare @NumberOfDaysToKeep int
set @NumberOfDaysToKeep = 60
begin transaction


    insert into [dbo].[ArchiveTasks] 
	([Id],[Title],[Priority],[Status],[AssignedToUserId],[FormLayout],[Data],[Action],[Type],
	[TenantId],[OrganizationUnitId],[LastModificationTime],[LastModifierUserId],[CreationTime],
	[CreatorUserId],[IsDeleted],[DeleterUserId],[DeletionTime],[TaskCatalogId],[IsCompleted],
	[ExternalTag])
    select
    [Id],[Title],[Priority],[Status],[AssignedToUserId],[FormLayout],[Data],[Action],[Type],
	[TenantId],[OrganizationUnitId],    [LastModificationTime],[LastModifierUserId],[CreationTime],
	[CreatorUserId],[IsDeleted],[DeleterUserId],[DeletionTime],[TaskCatalogId],[IsCompleted],
	[ExternalTag] 
    from [dbo].[TasksExternal]--[UiPath].[dbo].[Tasks] 
    where 1=1 
    and ((IsDeleted = 1 and DateDiff(day, DeletionTime, GetDate()) > @NumberOfDaysToKeep)
    or (Status = 2
    /*
      0 = Unassigned, 1 = Pending, 2 = Completed
    */
    -- and TenantId = 1 -- default tenant
    -- and OrganizationUnitId = 1 -- switch to the OrganizationUnit for which you want to delete
    and DateDiff(day, LastModificationTime, GetDate()) > @NumberOfDaysToKeep))
    
commit transaction