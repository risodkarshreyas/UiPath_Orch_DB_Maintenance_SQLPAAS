declare @NumberOfDaysToKeep int
set @NumberOfDaysToKeep = 60
begin transaction
-- create temp table with list of IDs that we want to delete
select ID as IdToDelete into #TempDeletedIds from [dbo].[AuditLogsExternal]
where 1=1
-- and TenantId = 1
and DateDiff(day, ExecutionTime, GetDate()) > @NumberOfDaysToKeep

-------------------- AuditLogEntities
insert into [dbo].[ArchiveAuditLogEntities]
([Id],[EntityName],[EntityId],[AuditLogId],[CustomData],[Action],[TenantId])
select
[Id],[EntityName],[EntityId],[AuditLogId],[CustomData],[Action],[TenantId]
from [dbo].[AuditLogEntitiesExternal] --[UiPath].[dbo].[AuditLogEntities]
where Exists (select 1 from #TempDeletedIds where IdToDelete = AuditLogId)

-------------------- AuditLogs
insert into [dbo].[ArchiveAuditLogs]
([Id],[TenantId],[UserId],[ServiceName],[MethodName],[Parameters],[ExecutionTime],[ExecutionDuration]
,[ClientIpAddress],[ClientName],[BrowserInfo],[Exception],[ImpersonatorUserId],[ImpersonatorTenantId]
,[CustomData],[Action],[Component],[DisplayName],[Version],[EntityId],[Discriminator],[ReturnValue],[IsGlobal])
select
[Id],[TenantId],[UserId],[ServiceName],[MethodName],[Parameters],[ExecutionTime],[ExecutionDuration]
,[ClientIpAddress],[ClientName],[BrowserInfo],[Exception],[ImpersonatorUserId],[ImpersonatorTenantId]
,[CustomData],[Action],[Component],[DisplayName],[Version],[EntityId],[Discriminator],[ReturnValue],[IsGlobal]
from [dbo].[AuditLogsExternal]--[UiPath].[dbo].[AuditLogs]
where Exists (select 1 from #TempDeletedIds where IdToDelete = [dbo].[AuditLogsExternal].[Id])

drop table #TempDeletedIds
commit transaction