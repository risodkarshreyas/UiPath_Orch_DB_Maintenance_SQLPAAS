declare @NumberOfDaysToKeep int
set @NumberOfDaysToKeep = 60
begin transaction

insert into [dbo].[ArchiveJobs]
([Id],[TenantId],[Key],[StartTime],[EndTime],[State],[RobotId],[ReleaseId]
,[Source],[BatchExecutionKey],[Info],[IsDeleted],[DeleterUserId],[DeletionTime]
,[LastModificationTime],[LastModifierUserId],[CreationTime],[CreatorUserId]
,[OrganizationUnitId],[StartingScheduleId],[Type],[InputArguments],[OutputArguments],[HostMachineName],
[PersistenceId],[ResumeVersion],[SuspendBlobType],[PersistenceLocationVersion],[StopStrategy],
[ReleaseVersionId],[EntryPointPath],[JobPriority],[RuntimeType],[MachineId],[RequiresUserInteraction],
[ServiceUserName],[ResumeTime],[Reference])
select
[Id],[TenantId],[Key],[StartTime],[EndTime],[State],[RobotId],[ReleaseId]
,[Source],[BatchExecutionKey],[Info],[IsDeleted],[DeleterUserId],[DeletionTime]
,[LastModificationTime],[LastModifierUserId],[CreationTime],[CreatorUserId]
,[OrganizationUnitId],[StartingScheduleId],[Type],[InputArguments],[OutputArguments],[HostMachineName],
[PersistenceId],[ResumeVersion],[SuspendBlobType],[PersistenceLocationVersion],[StopStrategy],
[ReleaseVersionId],[EntryPointPath],[JobPriority],[RuntimeType],[MachineId],[RequiresUserInteraction],
[ServiceUserName],[ResumeTime],[Reference]
from [dbo].[JobsExternal]--[UiPath].[dbo].[Jobs]
where 1=1
-- and State = 5
/*
  0 = Pending, 1 = Running, 2 = Stopping, 3 = Terminating, 4 = Faulted, 
  5 = Successful, 6 = Stopped, 7 = Suspended, 8 = Resumed
*/
-- and TenantId = 1 -- default tenant
and DateDiff(day, CreationTime, GetDate()) > @NumberOfDaysToKeep

commit transaction