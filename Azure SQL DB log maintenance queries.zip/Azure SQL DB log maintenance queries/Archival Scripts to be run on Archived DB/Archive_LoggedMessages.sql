-------------------- To be executed on Archived DB
-------------------- [ArchiveLogs]

declare @NumberOfDaysToKeep int
set @NumberOfDaysToKeep = 60
begin transaction

insert into [dbo].[ArchiveLogs]
([Id],[OrganizationUnitId],[TenantId],[TimeStamp],[Level],[WindowsIdentity]
,[ProcessName],[JobKey],[RobotName],[Message],[RawMessage],[MachineId],[UserKey],[HostMachineName])
select 
[Id],[OrganizationUnitId],[TenantId],[TimeStamp],[Level],[WindowsIdentity]
,[ProcessName],[JobKey],[RobotName],[Message],[RawMessage],[MachineId],[UserKey],[HostMachineName]
from [dbo].[LogsExternal]
where 1=1 and DateDiff(day, TimeStamp, GetDate()) > @NumberOfDaysToKeep

-- and level = 2
/*
  0 = Verbose, 1 = Trace, 2 = Info,
  3 = Warn, 4 = Error, 5 = Fatal
*/
-- and TenantId = 1 -- default tenant
--set identity_insert [UiPathOrchestratorArchives].[dbo].[ArchiveLogs] off

commit transaction
