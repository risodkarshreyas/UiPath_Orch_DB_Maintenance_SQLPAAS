-------------------- To be executed on Archived DB
declare @NumberOfDaysToKeep int
set @NumberOfDaysToKeep = 60
begin transaction
-- create temp table with list of IDs that we want to delete
select ID as IdToDelete into #TempDeletedIds from [dbo].[QueueItemsExternal]--QueueItems
where status=3
-- and TenantId = 1
-- and ReviewStatus != 0
and DateDiff(day, CreationTime, GetDate()) > @NumberOfDaysToKeep


-------------------- QueueItemEvents

insert into [dbo].[ArchiveQueueItemEvents]
([Id],[TenantId],[OrganizationUnitId],[QueueItemId],[TimeStamp],[Action],[UserId],[Status],[ReviewStatus],
[ReviewerUserId],[CreationTime],[CreatorUserId])
select
[Id],[TenantId],[OrganizationUnitId],[QueueItemId],[TimeStamp],[Action],[UserId],[Status],[ReviewStatus],
[ReviewerUserId],[CreationTime],[CreatorUserId]
from [dbo].[QueueItemEventsExternal] --[UiPath].[dbo].[QueueItemEvents]
where Exists (select 1 from #TempDeletedIds where IdToDelete = QueueItemId)

-------------------- QueueItemComments

insert into [dbo].[ArchiveQueueItemComments]
([Id],[TenantId],[OrganizationUnitId],[QueueItemId],[Text],[IsDeleted],[DeleterUserId],[DeletionTime],
[LastModificationTime],[LastModifierUserId],[CreationTime],[CreatorUserId])
select
[Id],[TenantId],[OrganizationUnitId],[QueueItemId],[Text],[IsDeleted],[DeleterUserId],[DeletionTime],
[LastModificationTime],[LastModifierUserId],[CreationTime],[CreatorUserId]
from [dbo].[QueueItemCommentsExternal] --[UiPath].[dbo].[QueueItemComments]
where Exists (select 1 from #TempDeletedIds where IdToDelete = QueueItemId)


-------------------- QueueItems

insert into [dbo].[ArchiveQueueItems]
([Id],[Priority],[QueueDefinitionId],[Key],[Status],[ReviewStatus],[RobotId],[StartProcessing],
[EndProcessing],[SecondsInPreviousAttempts],[AncestorId],[RetryNumber],[SpecificData],[TenantId],
[LastModificationTime],[LastModifierUserId],[CreationTime],[CreatorUserId],[DeferDate],[DueDate],
[Progress],[Output],[OrganizationUnitId],[RowVersion],[ProcessingExceptionType],[HasDueDate],[Reference],
[ReviewerUserId],[ProcessingExceptionReason],[ProcessingExceptionDetails],
[ProcessingExceptionAssociatedImageFilePath],[ProcessingExceptionCreationTime],
[CreatorJobId],[ExecutorJobId],[AnalyticsData],[RiskSlaDate]
)
select 
[Id],[Priority],[QueueDefinitionId],[Key],[Status],[ReviewStatus],[RobotId],[StartProcessing],
[EndProcessing],[SecondsInPreviousAttempts],[AncestorId],[RetryNumber],[SpecificData],[TenantId],
[LastModificationTime],[LastModifierUserId],[CreationTime],[CreatorUserId],[DeferDate],[DueDate],
[Progress],[Output],[OrganizationUnitId],NULL,[ProcessingExceptionType],[HasDueDate],[Reference],
[ReviewerUserId],[ProcessingExceptionReason],[ProcessingExceptionDetails],
[ProcessingExceptionAssociatedImageFilePath],[ProcessingExceptionCreationTime],
[CreatorJobId],[ExecutorJobId],[AnalyticsData],[RiskSlaDate]
from [dbo].[QueueItemsExternal]--[UiPath].[dbo].[QueueItems]
where Exists (select 1 from #TempDeletedIds where IdToDelete = [dbo].[QueueItemsExternal].[Id])

drop table #TempDeletedIds

commit transaction