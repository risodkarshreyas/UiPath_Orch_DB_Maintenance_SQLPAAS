-------------------- To be executed on Archived DB

declare @NumberOfDaysToKeep int
set @NumberOfDaysToKeep = 60
begin transaction
--set identity_insert [dbo].[ArchiveRobotLicenseLogs] on
insert into [dbo].[ArchiveRobotLicenseLogs]
([Id],[RobotId],[StartDate],[EndDate],[RobotType],[TenantId],[Scope],[Key],[Slots],
[LicenseKey],[Properties],[ErrorCode],[JobKey])
select
[Id],[RobotId],[StartDate],[EndDate],[RobotType],[TenantId],[Scope],[Key],[Slots],
[LicenseKey],[Properties],[ErrorCode],[JobKey]
from [dbo].[RobotLicenseLogsExternal] --[dbo].[RobotLicenseLogs]
where EndDate is not null
-- and TenantId = 1 -- default tenant
and DateDiff(day, EndDate, GetDate()) > @NumberOfDaysToKeep
--set identity_insert [dbo].[ArchiveRobotLicenseLogs] off
commit transaction