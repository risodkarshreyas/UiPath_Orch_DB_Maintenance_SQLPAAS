declare @NumberOfDaysToKeep int
set @NumberOfDaysToKeep = 60
begin transaction
-- create a temp table with list of IDs that we want to delete
select ID as IdToDelete into #TempDeletedIds from [dbo].[TenantNotificationsExternal]--TenantNotifications
where 1=1
-- and TenantId = 1
and DateDiff(day, CreationTime, GetDate()) > @NumberOfDaysToKeep

-------------------- UserNotifications
insert into [dbo].[ArchiveUserNotifications]
([Id],[UserId],[TenantNotificationId],[State],[CreationTime],[TenantId])
select
[Id],[UserId],[TenantNotificationId],[State],[CreationTime],[TenantId]
from [dbo].[UserNotificationsExternal] --[UiPath].[dbo].[UserNotifications]
where Exists (select 1 from #TempDeletedIds where IdToDelete = TenantNotificationId)

-------------------- TenantNotifications
insert into [dbo].[ArchiveTenantNotifications]
([Id],[TenantId],[NotificationName],[Data],[DataTypeName],[EntityTypeName],
[EntityTypeAssemblyQualifiedName],[EntityId],[Severity],[CreationTime],[CreatorUserId])
select
[Id],[TenantId],[NotificationName],[Data],[DataTypeName],[EntityTypeName]
,[EntityTypeAssemblyQualifiedName],[EntityId],[Severity],[CreationTime],[CreatorUserId]
from [dbo].[TenantNotificationsExternal]--[UiPath].[dbo].[TenantNotifications]
where Exists (select 1 from #TempDeletedIds where IdToDelete = [dbo].[TenantNotificationsExternal].[Id])

drop table #TempDeletedIds
commit transaction