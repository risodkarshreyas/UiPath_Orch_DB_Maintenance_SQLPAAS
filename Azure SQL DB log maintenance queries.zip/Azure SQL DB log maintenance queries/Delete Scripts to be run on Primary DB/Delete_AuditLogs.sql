declare @NumberOfDaysToKeep int
set @NumberOfDaysToKeep = 60
begin transaction
-- create temp table with list of IDs that we want to delete
select ID as IdToDelete into #TempDeletedIds from AuditLogs
where 1=1
-- and TenantId = 1
and DateDiff(day, ExecutionTime, GetDate()) > @NumberOfDaysToKeep

delete from [dbo].[AuditLogEntities]
where Exists (select 1 from #TempDeletedIds where IdToDelete = AuditLogId)

delete from [dbo].[AuditLogs]
where Exists (select 1 from #TempDeletedIds where IdToDelete = [dbo].[AuditLogs].[Id])

drop table #TempDeletedIds
commit transaction