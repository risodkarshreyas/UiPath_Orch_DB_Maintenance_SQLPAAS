declare @NumberOfDaysToKeep int
set @NumberOfDaysToKeep = 45
begin transaction

-- Ledger table cleanup
DELETE FROM [dbo].[Ledger] WHERE  DateDiff(day, CreationTime, GetDate()) > @NumberOfDaysToKeep

--LedgerDeliveries table cleanup
DELETE FROM [dbo].[LedgerDeliveries] WHERE  DateDiff(day, LastUpdatedTime, GetDate()) > @NumberOfDaysToKeep

commit transaction