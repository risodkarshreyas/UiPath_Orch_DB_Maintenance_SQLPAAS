--To be executed on primary DB

declare @NumberOfDaysToKeep int
set @NumberOfDaysToKeep = 60
begin transaction

delete from [dbo].[Logs]
where 1=1
-- and level = 2
/*
  0 = Verbose, 1 = Trace, 2 = Info,
  3 = Warn, 4 = Error, 5 = Fatal
*/
-- and TenantId = 1 -- default tenant
and DateDiff(day, TimeStamp, GetDate()) > @NumberOfDaysToKeep

commit transaction