declare @NumberOfDaysToKeep int
set @NumberOfDaysToKeep = 60
begin transaction
-- create temp table with list of IDs that we want to delete
select ID as IdToDelete into #TempDeletedIds from QueueItems
where status=3
-- and TenantId = 1
-- and ReviewStatus != 0
and DateDiff(day, CreationTime, GetDate()) > @NumberOfDaysToKeep

delete from [dbo].[QueueItemEvents]
where Exists (select 1 from #TempDeletedIds where IdToDelete = QueueItemId)


delete from [dbo].[QueueItemComments]
where Exists (select 1 from #TempDeletedIds where IdToDelete = QueueItemId)


delete from [dbo].[QueueItems]
where Exists (select 1 from #TempDeletedIds where IdToDelete = [QueueItems].[Id])

drop table #TempDeletedIds
commit transaction
