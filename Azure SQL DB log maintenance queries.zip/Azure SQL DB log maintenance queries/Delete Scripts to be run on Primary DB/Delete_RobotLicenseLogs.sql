-------------------- To be executed on Primary DB

declare @NumberOfDaysToKeep int
set @NumberOfDaysToKeep = 60
begin transaction

delete from [dbo].[RobotLicenseLogs]
where EndDate is not null
-- and TenantId = 1 -- default tenant
and DateDiff(day, EndDate, GetDate()) > @NumberOfDaysToKeep

commit transaction
