declare @NumberOfDaysToKeep int
set @NumberOfDaysToKeep = 60

begin transaction
-- create a temp table with list of IDs that we want to delete
select ID as IdToDelete into #TempDeletedIds from [dbo].[TenantNotifications]
where 1=1
-- and TenantId = 1
and DateDiff(day, CreationTime, GetDate()) > @NumberOfDaysToKeep


delete from [dbo].[UserNotifications]
where Exists (select 1 from #TempDeletedIds where IdToDelete = TenantNotificationId)


delete from [dbo].[TenantNotifications]
where Exists (select 1 from #TempDeletedIds where IdToDelete = [dbo].[TenantNotifications].[Id])

drop table #TempDeletedIds
commit transaction