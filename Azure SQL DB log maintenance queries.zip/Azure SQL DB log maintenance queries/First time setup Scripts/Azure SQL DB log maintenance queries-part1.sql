CREATE MASTER KEY;
GO

-- credential maps to a login or contained user used to connect to remote database 
CREATE DATABASE SCOPED CREDENTIAL CrossDbCred -- credential name
WITH IDENTITY = 'priyesh-ha-db ',                    -- login or contained user name
SECRET = '';                    -- login or contained user password
GO

-- data source to remote Azure SQL Database server and database
CREATE EXTERNAL DATA SOURCE UiPathDB
WITH
(
    TYPE=RDBMS,                             -- data source type
    LOCATION='priyesh-ha-db.database.windows.net', -- Azure SQL Database server name
    DATABASE_NAME='UiPath',           -- database name
    CREDENTIAL=CrossDbCred                 -- credential used to connect to server / database  
);
GO

-- external table points to table in an external database with the identical structure
--********Logs********
CREATE EXTERNAL TABLE [dbo].[LogsExternal]
(
   [Id] [bigint] NOT NULL,
	[OrganizationUnitId] [bigint] NOT NULL,
	[TenantId] [int] NOT NULL,
	[TimeStamp] [datetime] NOT NULL,
	[Level] [int] NOT NULL,
	[WindowsIdentity] [nvarchar](max) NULL,
	[ProcessName] [nvarchar](max) NULL,
	[JobKey] [uniqueidentifier] NULL,
	[RobotName] [nvarchar](255) NULL,
	[Message] [nvarchar](max) NULL,
	[RawMessage] [nvarchar](max) NULL,
	[MachineId] [bigint] NULL,
	[UserKey] [uniqueidentifier] NULL,
	[HostMachineName] [nvarchar](255) NULL
)
WITH (DATA_SOURCE = [UiPathDB],  -- data source 
      SCHEMA_NAME = 'dbo',           -- external table schema
      OBJECT_NAME = 'Logs'       -- name of table in external database
     );
GO


select * into [dbo].[ArchiveLogs] from [dbo].[LogsExternal] where 1=2

--INSERT INTO [dbo].[ArchiveLogs]
--select * from [dbo].[LogsExternal]

--******** [ArchiveQueueItems]********

-- external table points to table in an external database with the identical structure
CREATE EXTERNAL TABLE [dbo].[QueueItemsExternal]
(
	[Id] [bigint]  NOT NULL,
	[Priority] [int] NOT NULL,
	[QueueDefinitionId] [bigint] NOT NULL,
	[Key] [uniqueidentifier] NOT NULL,
	[Status] [int] NOT NULL,
	[ReviewStatus] [int] NOT NULL,
	[RobotId] [bigint] NULL,
	[StartProcessing] [datetime] NULL,
	[EndProcessing] [datetime] NULL,
	[SecondsInPreviousAttempts] [int] NOT NULL,
	[AncestorId] [bigint] NULL,
	[RetryNumber] [int] NOT NULL,
	[SpecificData] [nvarchar](max) NULL,
	[TenantId] [int] NOT NULL,
	[LastModificationTime] [datetime] NULL,
	[LastModifierUserId] [bigint] NULL,
	[CreationTime] [datetime] NOT NULL,
	[CreatorUserId] [bigint] NULL,
	[DeferDate] [datetime] NULL,
	[DueDate] [datetime] NULL,
	[Progress] [nvarchar](max) NULL,
	[Output] [nvarchar](max) NULL,
	[OrganizationUnitId] [bigint] NULL,
	[RowVersion] [timestamp] NOT NULL,
	[ProcessingExceptionType] [int] NULL,
	[HasDueDate] [bit] NOT NULL,
	[Reference] [nvarchar](128) NULL,
	[ReviewerUserId] [bigint] NULL,
	[ProcessingExceptionReason] [nvarchar](max) NULL,
	[ProcessingExceptionDetails] [nvarchar](max) NULL,
	[ProcessingExceptionAssociatedImageFilePath] [nvarchar](max) NULL,
	[ProcessingExceptionCreationTime] [datetime] NULL,
	[CreatorJobId] [bigint] NULL,
	[ExecutorJobId] [bigint] NULL,
	[AnalyticsData] [nvarchar](max) NULL,
	[RiskSlaDate] [datetime] NULL,
	[HasRiskSlaDate] bit,  --AS (CONVERT([bit],case when [RiskSlaDate] IS NULL then (0) else (1) end)),
	[IsDeleted] [bit] NOT NULL,
	[DeleterUserId] [bigint] NULL,
	[DeletionTime] [datetime] NULL
)
WITH (DATA_SOURCE = [UiPathDB],  -- data source 
      SCHEMA_NAME = 'dbo',           -- external table schema
      OBJECT_NAME = 'QueueItems'       -- name of table in external database
     );
GO

select * into [dbo].[ArchiveQueueItems] from [dbo].[QueueItemsExternal] where 1=2

--INSERT INTO [dbo].[ArchiveQueueItems]
--select * from [dbo].[QueueItemsExternal]

--********[QueueItemEvents]********
CREATE EXTERNAL TABLE [dbo].[QueueItemEventsExternal]
(
	[Id] [bigint]  NOT NULL,
	[TenantId] [int] NOT NULL,
	[OrganizationUnitId] [bigint] NULL,
	[QueueItemId] [bigint] NOT NULL,
	[TimeStamp] [datetime] NOT NULL,
	[Action] [int] NOT NULL,
	[UserId] [bigint] NULL,
	[Status] [int] NOT NULL,
	[ReviewStatus] [int] NOT NULL,
	[ReviewerUserId] [bigint] NULL,
	[CreationTime] [datetime] NOT NULL,
	[CreatorUserId] [bigint] NULL,
	[DeleterUserId] [bigint] NULL,
	[DeletionTime] [datetime] NULL,
	[IsDeleted] [bit] NOT NULL,
	[QueueDefinitionId] [bigint] NULL
)
WITH (DATA_SOURCE = [UiPathDB],  -- data source 
      SCHEMA_NAME = 'dbo',           -- external table schema
      OBJECT_NAME = 'QueueItemEvents'       -- name of table in external database
     );
GO

select * into [dbo].[ArchiveQueueItemEvents] from [dbo].[QueueItemEventsExternal] where 1=2

--INSERT INTO [dbo].[ArchiveQueueItemEvents]
--select * from [dbo].[QueueItemEventsExternal]

--select * into [UiPathOrchestratorArchives].[dbo].[ArchiveQueueItemEvents] from 
--[UiPath].[dbo].[QueueItemEvents] where 1=2

--********QueueItemComments********
CREATE EXTERNAL TABLE [dbo].[QueueItemCommentsExternal]
(
	[Id] [bigint] NOT NULL,
	[TenantId] [int] NOT NULL,
	[OrganizationUnitId] [bigint] NULL,
	[QueueItemId] [bigint] NOT NULL,
	[Text] [nvarchar](512) NULL,
	[IsDeleted] [bit] NOT NULL,
	[DeleterUserId] [bigint] NULL,
	[DeletionTime] [datetime] NULL,
	[LastModificationTime] [datetime] NULL,
	[LastModifierUserId] [bigint] NULL,
	[CreationTime] [datetime] NOT NULL,
	[CreatorUserId] [bigint] NULL,
	[QueueDefinitionId] [bigint] NULL,
)
WITH (DATA_SOURCE = [UiPathDB],  -- data source 
      SCHEMA_NAME = 'dbo',           -- external table schema
      OBJECT_NAME = 'QueueItemComments'       -- name of table in external database
     );
GO

select * into [dbo].[ArchiveQueueItemComments] from [dbo].[QueueItemCommentsExternal] where 1=2

--INSERT INTO [dbo].[ArchiveQueueItemComments] 
--select * from [dbo].[QueueItemCommentsExternal]

--select * into [UiPathOrchestratorArchives].[dbo].[ArchiveQueueItemComments] from 
--[UiPath].[dbo].[QueueItemComments] where 
--1=2

--********RobotLicenseLogs********
CREATE EXTERNAL TABLE [dbo].[RobotLicenseLogsExternal]
(
	[Id] [bigint]  NOT NULL,
	[RobotId] [bigint] NULL,
	[StartDate] [datetime] NOT NULL,
	[EndDate] [datetime] NULL,
	[RobotType] [int] NOT NULL,
	[TenantId] [int] NOT NULL,
	[Scope] [int] NOT NULL,
	[Key] [nvarchar](256) NULL,
	[Slots] [int] NOT NULL,
	[LicenseKey] [nvarchar](max) NULL,
	[Properties] [nvarchar](max) NULL,
	[ErrorCode] [int] NULL,
	[JobKey] [nvarchar](255) NULL
)
WITH (DATA_SOURCE = [UiPathDB],  -- data source 
      SCHEMA_NAME = 'dbo',           -- external table schema
      OBJECT_NAME = 'RobotLicenseLogs'       -- name of table in external database
     );
GO

select * into [dbo].[ArchiveRobotLicenseLogs] from [dbo].[RobotLicenseLogsExternal] where 1=2

--INSERT INTO [dbo].[ArchiveRobotLicenseLogs] 
--select * from [dbo].[RobotLicenseLogsExternal]

--select * into [UiPathOrchestratorArchives].[dbo].[ArchiveRobotLicenseLogs] from
--[UiPath].[dbo].[RobotLicenseLogs] where 1=2

--********TenantNotifications********
CREATE EXTERNAL TABLE [dbo].[TenantNotificationsExternal]
(
	[Id] [uniqueidentifier] NOT NULL,
	[TenantId] [int] NULL,
	[NotificationName] [nvarchar](96) NOT NULL,
	[Data] [nvarchar](max) NULL,
	[DataTypeName] [nvarchar](512) NULL,
	[EntityTypeName] [nvarchar](250) NULL,
	[EntityTypeAssemblyQualifiedName] [nvarchar](512) NULL,
	[EntityId] [nvarchar](96) NULL,
	[Severity] [tinyint] NOT NULL,
	[CreationTime] [datetime] NOT NULL,
	[CreatorUserId] [bigint] NULL,
)
WITH (DATA_SOURCE = [UiPathDB],  -- data source 
      SCHEMA_NAME = 'dbo',           -- external table schema
      OBJECT_NAME = 'TenantNotifications'       -- name of table in external database
     );
GO

select * into [dbo].[ArchiveTenantNotifications] from [dbo].[TenantNotificationsExternal] where 1=2

--INSERT INTO [dbo].[ArchiveTenantNotifications] 
--select * from [dbo].[TenantNotificationsExternal]

--select * into [UiPathOrchestratorArchives].[dbo].[ArchiveTenantNotifications] from
--[UiPath].[dbo].[TenantNotifications] where 1=2

--********UserNotifications********
CREATE EXTERNAL TABLE [dbo].[UserNotificationsExternal]
(
	[Id] [uniqueidentifier] NOT NULL,
	[UserId] [bigint] NOT NULL,
	[TenantNotificationId] [uniqueidentifier] NOT NULL,
	[State] [int] NOT NULL,
	[CreationTime] [datetime] NOT NULL,
	[TenantId] [int] NULL,
)
WITH (DATA_SOURCE = [UiPathDB],  -- data source 
      SCHEMA_NAME = 'dbo',           -- external table schema
      OBJECT_NAME = 'UserNotifications'       -- name of table in external database
     );
GO


select * into [dbo].[ArchiveUserNotifications] from [dbo].[UserNotificationsExternal] where 1=2

--INSERT INTO [dbo].[ArchiveUserNotifications] 
--select * from [dbo].[UserNotificationsExternal]

--select * into [UiPathOrchestratorArchives].[dbo].[ArchiveUserNotifications] from 
--[UiPath].[dbo].[UserNotifications] where 1=2

--********Jobs********
CREATE EXTERNAL TABLE [dbo].[JobsExternal]
(
	[Id] [bigint]  NOT NULL,
	[TenantId] [int] NOT NULL,
	[Key] [uniqueidentifier] NOT NULL,
	[StartTime] [datetime] NULL,
	[EndTime] [datetime] NULL,
	[State] [int] NOT NULL,
	[RobotId] [bigint] NULL,
	[ReleaseId] [bigint] NULL,
	[Source] [int] NOT NULL,
	[BatchExecutionKey] [uniqueidentifier] NOT NULL,
	[Info] [nvarchar](max) NULL,
	[IsDeleted] [bit] NOT NULL,
	[DeleterUserId] [bigint] NULL,
	[DeletionTime] [datetime] NULL,
	[LastModificationTime] [datetime] NULL,
	[LastModifierUserId] [bigint] NULL,
	[CreationTime] [datetime] NOT NULL,
	[CreatorUserId] [bigint] NULL,
	[OrganizationUnitId] [bigint] NOT NULL,
	[StartingScheduleId] [bigint] NULL,
	[Type] [int] NOT NULL,
	[InputArguments] [nvarchar](max) NULL,
	[OutputArguments] [nvarchar](max) NULL,
	[HostMachineName] [nvarchar](255) NULL,
	[PersistenceId] [uniqueidentifier] NULL,
	[ResumeVersion] [int] NULL,
	[SuspendBlobType] [int] NULL,
	[PersistenceLocationVersion] [int] NULL,
	[StopStrategy] [int] NULL,
	[ReleaseVersionId] [bigint] NULL,
	[EntryPointPath] [nvarchar](512) NULL,
	[JobPriority] [int] NOT NULL,
	[RuntimeType] [int] NULL,
	[MachineId] [bigint] NULL,
	[RequiresUserInteraction] [bit] NOT NULL,
	[ServiceUserName] [nvarchar](max) NULL,
	[ResumeTime] [datetime] NULL,
	[Reference] [nvarchar](128) NOT NULL,
	[ProcessType] [int] NOT NULL,
	[ProfilingOptions] [nvarchar](max) NULL,
	[ResumeOnSameContext] [bit] NOT NULL,
	[TargetFramework] [int] NOT NULL,
	[LocalSystemAccount] [nvarchar](100) NULL
)
WITH (DATA_SOURCE = [UiPathDB],  -- data source 
      SCHEMA_NAME = 'dbo',           -- external table schema
      OBJECT_NAME = 'Jobs'       -- name of table in external database
     );
GO

select * into [dbo].[ArchiveJobs] from 
[dbo].[JobsExternal] where 1=2

--INSERT INTO [dbo].[ArchiveJobs] 
--select * from [dbo].[JobsExternal]

--select * into [UiPathOrchestratorArchives].[dbo].[ArchiveJobs] from
--[UiPath].[dbo].[Jobs] where 1=2


--********AuditLogs********
CREATE EXTERNAL TABLE [dbo].[AuditLogsExternal]
(
	[Id] [bigint] NOT NULL,
	[TenantId] [int] NULL,
	[UserId] [bigint] NULL,
	[ServiceName] [nvarchar](256) NULL,
	[MethodName] [nvarchar](256) NULL,
	[Parameters] [nvarchar](max) NULL,
	[ExecutionTime] [datetime] NOT NULL,
	[ExecutionDuration] [int] NOT NULL,
	[ClientIpAddress] [nvarchar](64) NULL,
	[ClientName] [nvarchar](128) NULL,
	[BrowserInfo] [nvarchar](512) NULL,
	[Exception] [nvarchar](2000) NULL,
	[ImpersonatorUserId] [bigint] NULL,
	[ImpersonatorTenantId] [int] NULL,
	[CustomData] [nvarchar](2000) NULL,
	[Action] [int] NULL,
	[Component] [int] NULL,
	[DisplayName] [nvarchar](max) NULL,
	[Version] [int] NULL,
	[EntityId] [bigint] NULL,
	[Discriminator] [nvarchar](128) NOT NULL,
	[ReturnValue] [nvarchar](max) NULL,
	[IsGlobal] [bit] NOT NULL,
	[Key] [uniqueidentifier] NULL,
	[ExternalClientId] [nvarchar](256) NULL,
	[ExceptionMessage] [nvarchar](1024) NULL,
	)
WITH (DATA_SOURCE = [UiPathDB],  -- data source 
      SCHEMA_NAME = 'dbo',           -- external table schema
      OBJECT_NAME = 'AuditLogs'       -- name of table in external database
     );
GO

select * into [dbo].[ArchiveAuditLogs] from 
[dbo].[AuditLogsExternal] where 1=2

--INSERT INTO [dbo].[ArchiveAuditLogs] 
--select * from [dbo].[AuditLogsExternal]

--select * into [UiPathOrchestratorArchives].[dbo].[ArchiveAuditLogs] from
--[UiPath].[dbo].[AuditLogs] where 1=2

--********AuditLogEntities********
CREATE EXTERNAL TABLE [dbo].[AuditLogEntitiesExternal]
(
	[Id] [bigint] NOT NULL,
	[EntityName] [nvarchar](256) NULL,
	[EntityId] [bigint] NULL,
	[AuditLogId] [bigint] NOT NULL,
	[CustomData] [nvarchar](max) NULL,
	[Action] [int] NOT NULL,
	[TenantId] [int] NULL
)
WITH (DATA_SOURCE = [UiPathDB],  -- data source 
      SCHEMA_NAME = 'dbo',           -- external table schema
      OBJECT_NAME = 'AuditLogEntities'       -- name of table in external database
     );
GO

select * into [dbo].[ArchiveAuditLogEntities] from 
[dbo].[AuditLogEntitiesExternal] where 1=2

--INSERT INTO [dbo].[ArchiveAuditLogEntities] 
--select * from [dbo].[AuditLogEntitiesExternal]

--select * into [UiPathOrchestratorArchives].[dbo].[ArchiveAuditLogEntities] from
--[UiPath].[dbo].[AuditLogEntities] where 1=2

--********Tasks********
CREATE EXTERNAL TABLE [dbo].[TasksExternal]
(
	[Id] [bigint] NOT NULL,
	[Title] [nvarchar](512) NOT NULL,
	[Priority] [int] NOT NULL,
	[Status] [int] NOT NULL,
	[AssignedToUserId] [bigint] NULL,
	[FormLayout] [nvarchar](max) NULL,
	[Data] [nvarchar](max) NULL,
	[Action] [nvarchar](max) NULL,
	[Type] [int] NOT NULL,
	[TenantId] [int] NOT NULL,
	[OrganizationUnitId] [bigint] NOT NULL,
	[RowVersion] [timestamp] NOT NULL,
	[LastModificationTime] [datetime] NULL,
	[LastModifierUserId] [bigint] NULL,
	[CreationTime] [datetime] NOT NULL,
	[CreatorUserId] [bigint] NULL,
	[IsDeleted] [bit] NOT NULL,
	[DeleterUserId] [bigint] NULL,
	[DeletionTime] [datetime] NULL,
	[TaskCatalogId] [bigint] NULL,
	[IsCompleted]  bit,--AS (CONVERT([bit],case [Status] when (2) then (1) else (0) end)) PERSISTED,
	[ExternalTag] [nvarchar](128) NULL,
	[CreatorJobKey] [uniqueidentifier] NULL,
	[WaitJobKey] [uniqueidentifier] NULL,
	[FormLayoutId] [bigint] NULL,
	[BulkFormLayoutId] [bigint] NULL

)
WITH (DATA_SOURCE = [UiPathDB],  -- data source 
      SCHEMA_NAME = 'dbo',           -- external table schema
      OBJECT_NAME = 'Tasks'       -- name of table in external database
     );
GO

select * into [dbo].[ArchiveTasks] from 
[dbo].[TasksExternal] where 1=2

--INSERT INTO [dbo].[ArchiveTasks] 
--select * from [dbo].[TasksExternal]

--select * into [UiPathOrchestratorArchives].[dbo].[ArchiveTasks] from 
--[UiPath].[dbo].[Tasks] where 1=2